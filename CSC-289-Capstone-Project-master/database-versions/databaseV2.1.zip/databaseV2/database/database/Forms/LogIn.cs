﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ClassEngine;

namespace database
{
    public partial class logInForm : Form
    {
        ClassEngine.SQLCommands com = new ClassEngine.SQLCommands();        
        public logInForm()
        {
            InitializeComponent();
        }
        public void LogIn()
        {
            bool logIn;
            string userName = usernameTextBox.Text;
            string password = passwordTextBox.Text;
            logIn = com.LogInRetrieval(userName, password);
            if (logIn == true)
            {
                Forms.userForm user = new Forms.userForm();
                user.ShowDialog();
                usernameTextBox.Clear();
                passwordTextBox.Clear();
            }
            else
            {
                MessageBox.Show("The information you have entered does not match our records.");
                usernameTextBox.Clear();
                passwordTextBox.Clear();
            }
        }
        private void logInButton_Click(object sender, EventArgs e)
        {
            LogIn();
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank you for choosing Case Tracker.");
            this.Close();
        }
    }
}
