﻿namespace database.Forms
{
    partial class userForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.welcomeLabel = new System.Windows.Forms.Label();
            this.nameLabel = new System.Windows.Forms.Label();
            this.activeCaseButton = new System.Windows.Forms.Button();
            this.searchCaseButton = new System.Windows.Forms.Button();
            this.newCaseButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // welcomeLabel
            // 
            this.welcomeLabel.AutoSize = true;
            this.welcomeLabel.Location = new System.Drawing.Point(151, 40);
            this.welcomeLabel.Name = "welcomeLabel";
            this.welcomeLabel.Size = new System.Drawing.Size(70, 17);
            this.welcomeLabel.TabIndex = 0;
            this.welcomeLabel.Text = "Welcome:";
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(227, 40);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(0, 17);
            this.nameLabel.TabIndex = 1;
            // 
            // activeCaseButton
            // 
            this.activeCaseButton.Location = new System.Drawing.Point(71, 89);
            this.activeCaseButton.Name = "activeCaseButton";
            this.activeCaseButton.Size = new System.Drawing.Size(75, 45);
            this.activeCaseButton.TabIndex = 2;
            this.activeCaseButton.Text = "View Active Cases";
            this.activeCaseButton.UseVisualStyleBackColor = true;
            // 
            // searchCaseButton
            // 
            this.searchCaseButton.Location = new System.Drawing.Point(152, 89);
            this.searchCaseButton.Name = "searchCaseButton";
            this.searchCaseButton.Size = new System.Drawing.Size(75, 45);
            this.searchCaseButton.TabIndex = 3;
            this.searchCaseButton.Text = "Search Cases";
            this.searchCaseButton.UseVisualStyleBackColor = true;
            // 
            // newCaseButton
            // 
            this.newCaseButton.Location = new System.Drawing.Point(233, 89);
            this.newCaseButton.Name = "newCaseButton";
            this.newCaseButton.Size = new System.Drawing.Size(75, 45);
            this.newCaseButton.TabIndex = 4;
            this.newCaseButton.Text = "Create New Case";
            this.newCaseButton.UseVisualStyleBackColor = true;
            // 
            // userForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(379, 168);
            this.Controls.Add(this.newCaseButton);
            this.Controls.Add(this.searchCaseButton);
            this.Controls.Add(this.activeCaseButton);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.welcomeLabel);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "userForm";
            this.Text = "UserForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label welcomeLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Button activeCaseButton;
        private System.Windows.Forms.Button searchCaseButton;
        private System.Windows.Forms.Button newCaseButton;
    }
}