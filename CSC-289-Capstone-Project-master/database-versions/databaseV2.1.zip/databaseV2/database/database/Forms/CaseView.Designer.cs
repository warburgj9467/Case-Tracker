﻿namespace database.Forms
{
    partial class CaseView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.individualAtRiskTabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.indivPhoneLabel = new System.Windows.Forms.Label();
            this.indivPhoneTextBox = new System.Windows.Forms.TextBox();
            this.indivRelationshipLabel = new System.Windows.Forms.Label();
            this.indivRelationshipTextBox = new System.Windows.Forms.TextBox();
            this.indivStateLabel = new System.Windows.Forms.Label();
            this.indivStateTextBox = new System.Windows.Forms.TextBox();
            this.indivZipLabel = new System.Windows.Forms.Label();
            this.indivZipTextBox = new System.Windows.Forms.TextBox();
            this.indivCityTextBox = new System.Windows.Forms.TextBox();
            this.indivCityLabel = new System.Windows.Forms.Label();
            this.indivAddressTextBox = new System.Windows.Forms.TextBox();
            this.indivAddressLabel = new System.Windows.Forms.Label();
            this.indivSSNTextBox = new System.Windows.Forms.TextBox();
            this.indivSSNLabel = new System.Windows.Forms.Label();
            this.indivDOBTextBox = new System.Windows.Forms.TextBox();
            this.indivLastNameLabel = new System.Windows.Forms.Label();
            this.indivDOBLabel = new System.Windows.Forms.Label();
            this.indivLastNameTextBox = new System.Windows.Forms.TextBox();
            this.indivFirstNameTextBox = new System.Windows.Forms.TextBox();
            this.indivFirstNameLabel = new System.Windows.Forms.Label();
            this.caregiverTabPage = new System.Windows.Forms.TabPage();
            this.carePhoneLabel = new System.Windows.Forms.Label();
            this.carePhoneTextBox = new System.Windows.Forms.TextBox();
            this.careRelationshipLabel = new System.Windows.Forms.Label();
            this.careRelationshipTextBox = new System.Windows.Forms.TextBox();
            this.careStateLabel = new System.Windows.Forms.Label();
            this.careStateTextBox = new System.Windows.Forms.TextBox();
            this.careZipLabel = new System.Windows.Forms.Label();
            this.careZipTextBox = new System.Windows.Forms.TextBox();
            this.careCityTextBox = new System.Windows.Forms.TextBox();
            this.careCityLabel = new System.Windows.Forms.Label();
            this.careAddressTextBox = new System.Windows.Forms.TextBox();
            this.careAddressLabel = new System.Windows.Forms.Label();
            this.careSNNTextBox = new System.Windows.Forms.TextBox();
            this.careSSNLabel = new System.Windows.Forms.Label();
            this.careDOBTextBox = new System.Windows.Forms.TextBox();
            this.careLastNameLabel = new System.Windows.Forms.Label();
            this.careDOBLabel = new System.Windows.Forms.Label();
            this.careLastNameTextBox = new System.Windows.Forms.TextBox();
            this.careFirstNameTextBox = new System.Windows.Forms.TextBox();
            this.careFirstNameLabel = new System.Windows.Forms.Label();
            this.perpetratorTabPage = new System.Windows.Forms.TabPage();
            this.perpPhoneLabel = new System.Windows.Forms.Label();
            this.perpPhoneTextBox = new System.Windows.Forms.TextBox();
            this.perpRelationshipLabel = new System.Windows.Forms.Label();
            this.perpRelationshipTextBox = new System.Windows.Forms.TextBox();
            this.perpStateLabel = new System.Windows.Forms.Label();
            this.perpStateTextBox = new System.Windows.Forms.TextBox();
            this.perpZipLabel = new System.Windows.Forms.Label();
            this.perpZipTextBox = new System.Windows.Forms.TextBox();
            this.perpCityTextBox = new System.Windows.Forms.TextBox();
            this.perpCityLabel1 = new System.Windows.Forms.Label();
            this.perpAddressTextBox = new System.Windows.Forms.TextBox();
            this.perpAddressLabel = new System.Windows.Forms.Label();
            this.perpSSNTextBox = new System.Windows.Forms.TextBox();
            this.perpSSNLabel = new System.Windows.Forms.Label();
            this.perpDOBTextBox = new System.Windows.Forms.TextBox();
            this.perpLastNameLabel = new System.Windows.Forms.Label();
            this.perpDOBLabel = new System.Windows.Forms.Label();
            this.perpLastNameTextBox = new System.Windows.Forms.TextBox();
            this.perpFirstNameTextBox = new System.Windows.Forms.TextBox();
            this.perpFirstNameLabel = new System.Windows.Forms.Label();
            this.indivApartmentTextBox = new System.Windows.Forms.TextBox();
            this.indivApartmentLabel = new System.Windows.Forms.Label();
            this.indivSchoolTextBox = new System.Windows.Forms.TextBox();
            this.indivSchoolLabel = new System.Windows.Forms.Label();
            this.careApartmentLabel = new System.Windows.Forms.Label();
            this.careApartmentTextBox = new System.Windows.Forms.TextBox();
            this.perpApartmentLabel = new System.Windows.Forms.Label();
            this.perpApartmentTextBox = new System.Windows.Forms.TextBox();
            this.indivSaveButton = new System.Windows.Forms.Button();
            this.careSaveButton = new System.Windows.Forms.Button();
            this.perpSaveButton = new System.Windows.Forms.Button();
            this.caseViewExitButton = new System.Windows.Forms.Button();
            this.individualAtRiskTabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.caregiverTabPage.SuspendLayout();
            this.perpetratorTabPage.SuspendLayout();
            this.SuspendLayout();
            // 
            // individualAtRiskTabControl
            // 
            this.individualAtRiskTabControl.Controls.Add(this.tabPage1);
            this.individualAtRiskTabControl.Controls.Add(this.caregiverTabPage);
            this.individualAtRiskTabControl.Controls.Add(this.perpetratorTabPage);
            this.individualAtRiskTabControl.Location = new System.Drawing.Point(12, 12);
            this.individualAtRiskTabControl.Name = "individualAtRiskTabControl";
            this.individualAtRiskTabControl.SelectedIndex = 0;
            this.individualAtRiskTabControl.Size = new System.Drawing.Size(431, 256);
            this.individualAtRiskTabControl.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.indivSaveButton);
            this.tabPage1.Controls.Add(this.indivSchoolLabel);
            this.tabPage1.Controls.Add(this.indivSchoolTextBox);
            this.tabPage1.Controls.Add(this.indivApartmentLabel);
            this.tabPage1.Controls.Add(this.indivApartmentTextBox);
            this.tabPage1.Controls.Add(this.indivPhoneLabel);
            this.tabPage1.Controls.Add(this.indivPhoneTextBox);
            this.tabPage1.Controls.Add(this.indivRelationshipLabel);
            this.tabPage1.Controls.Add(this.indivRelationshipTextBox);
            this.tabPage1.Controls.Add(this.indivStateLabel);
            this.tabPage1.Controls.Add(this.indivStateTextBox);
            this.tabPage1.Controls.Add(this.indivZipLabel);
            this.tabPage1.Controls.Add(this.indivZipTextBox);
            this.tabPage1.Controls.Add(this.indivCityTextBox);
            this.tabPage1.Controls.Add(this.indivCityLabel);
            this.tabPage1.Controls.Add(this.indivAddressTextBox);
            this.tabPage1.Controls.Add(this.indivAddressLabel);
            this.tabPage1.Controls.Add(this.indivSSNTextBox);
            this.tabPage1.Controls.Add(this.indivSSNLabel);
            this.tabPage1.Controls.Add(this.indivDOBTextBox);
            this.tabPage1.Controls.Add(this.indivLastNameLabel);
            this.tabPage1.Controls.Add(this.indivDOBLabel);
            this.tabPage1.Controls.Add(this.indivLastNameTextBox);
            this.tabPage1.Controls.Add(this.indivFirstNameTextBox);
            this.tabPage1.Controls.Add(this.indivFirstNameLabel);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(423, 227);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Individual at Risk";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // indivPhoneLabel
            // 
            this.indivPhoneLabel.AutoSize = true;
            this.indivPhoneLabel.Location = new System.Drawing.Point(246, 156);
            this.indivPhoneLabel.Name = "indivPhoneLabel";
            this.indivPhoneLabel.Size = new System.Drawing.Size(49, 17);
            this.indivPhoneLabel.TabIndex = 58;
            this.indivPhoneLabel.Text = "Phone";
            // 
            // indivPhoneTextBox
            // 
            this.indivPhoneTextBox.Location = new System.Drawing.Point(301, 153);
            this.indivPhoneTextBox.Name = "indivPhoneTextBox";
            this.indivPhoneTextBox.Size = new System.Drawing.Size(100, 22);
            this.indivPhoneTextBox.TabIndex = 57;
            // 
            // indivRelationshipLabel
            // 
            this.indivRelationshipLabel.AutoSize = true;
            this.indivRelationshipLabel.Location = new System.Drawing.Point(9, 72);
            this.indivRelationshipLabel.Name = "indivRelationshipLabel";
            this.indivRelationshipLabel.Size = new System.Drawing.Size(86, 17);
            this.indivRelationshipLabel.TabIndex = 56;
            this.indivRelationshipLabel.Text = "Relationship";
            // 
            // indivRelationshipTextBox
            // 
            this.indivRelationshipTextBox.Location = new System.Drawing.Point(101, 69);
            this.indivRelationshipTextBox.Name = "indivRelationshipTextBox";
            this.indivRelationshipTextBox.Size = new System.Drawing.Size(100, 22);
            this.indivRelationshipTextBox.TabIndex = 55;
            // 
            // indivStateLabel
            // 
            this.indivStateLabel.AutoSize = true;
            this.indivStateLabel.Location = new System.Drawing.Point(254, 100);
            this.indivStateLabel.Name = "indivStateLabel";
            this.indivStateLabel.Size = new System.Drawing.Size(41, 17);
            this.indivStateLabel.TabIndex = 54;
            this.indivStateLabel.Text = "State";
            // 
            // indivStateTextBox
            // 
            this.indivStateTextBox.Location = new System.Drawing.Point(301, 97);
            this.indivStateTextBox.Name = "indivStateTextBox";
            this.indivStateTextBox.Size = new System.Drawing.Size(100, 22);
            this.indivStateTextBox.TabIndex = 53;
            // 
            // indivZipLabel
            // 
            this.indivZipLabel.AutoSize = true;
            this.indivZipLabel.Location = new System.Drawing.Point(267, 128);
            this.indivZipLabel.Name = "indivZipLabel";
            this.indivZipLabel.Size = new System.Drawing.Size(28, 17);
            this.indivZipLabel.TabIndex = 52;
            this.indivZipLabel.Text = "Zip";
            // 
            // indivZipTextBox
            // 
            this.indivZipTextBox.Location = new System.Drawing.Point(301, 125);
            this.indivZipTextBox.Name = "indivZipTextBox";
            this.indivZipTextBox.Size = new System.Drawing.Size(100, 22);
            this.indivZipTextBox.TabIndex = 51;
            // 
            // indivCityTextBox
            // 
            this.indivCityTextBox.Location = new System.Drawing.Point(301, 69);
            this.indivCityTextBox.Name = "indivCityTextBox";
            this.indivCityTextBox.Size = new System.Drawing.Size(100, 22);
            this.indivCityTextBox.TabIndex = 50;
            // 
            // indivCityLabel
            // 
            this.indivCityLabel.AutoSize = true;
            this.indivCityLabel.Location = new System.Drawing.Point(264, 72);
            this.indivCityLabel.Name = "indivCityLabel";
            this.indivCityLabel.Size = new System.Drawing.Size(31, 17);
            this.indivCityLabel.TabIndex = 49;
            this.indivCityLabel.Text = "City";
            // 
            // indivAddressTextBox
            // 
            this.indivAddressTextBox.Location = new System.Drawing.Point(301, 13);
            this.indivAddressTextBox.Name = "indivAddressTextBox";
            this.indivAddressTextBox.Size = new System.Drawing.Size(100, 22);
            this.indivAddressTextBox.TabIndex = 48;
            // 
            // indivAddressLabel
            // 
            this.indivAddressLabel.AutoSize = true;
            this.indivAddressLabel.Location = new System.Drawing.Point(235, 16);
            this.indivAddressLabel.Name = "indivAddressLabel";
            this.indivAddressLabel.Size = new System.Drawing.Size(60, 17);
            this.indivAddressLabel.TabIndex = 40;
            this.indivAddressLabel.Text = "Address";
            // 
            // indivSSNTextBox
            // 
            this.indivSSNTextBox.Location = new System.Drawing.Point(101, 125);
            this.indivSSNTextBox.Name = "indivSSNTextBox";
            this.indivSSNTextBox.Size = new System.Drawing.Size(100, 22);
            this.indivSSNTextBox.TabIndex = 47;
            // 
            // indivSSNLabel
            // 
            this.indivSSNLabel.AutoSize = true;
            this.indivSSNLabel.Location = new System.Drawing.Point(59, 128);
            this.indivSSNLabel.Name = "indivSSNLabel";
            this.indivSSNLabel.Size = new System.Drawing.Size(36, 17);
            this.indivSSNLabel.TabIndex = 46;
            this.indivSSNLabel.Text = "SSN";
            // 
            // indivDOBTextBox
            // 
            this.indivDOBTextBox.Location = new System.Drawing.Point(101, 97);
            this.indivDOBTextBox.Name = "indivDOBTextBox";
            this.indivDOBTextBox.Size = new System.Drawing.Size(100, 22);
            this.indivDOBTextBox.TabIndex = 45;
            // 
            // indivLastNameLabel
            // 
            this.indivLastNameLabel.AutoSize = true;
            this.indivLastNameLabel.Location = new System.Drawing.Point(19, 16);
            this.indivLastNameLabel.Name = "indivLastNameLabel";
            this.indivLastNameLabel.Size = new System.Drawing.Size(76, 17);
            this.indivLastNameLabel.TabIndex = 39;
            this.indivLastNameLabel.Text = "Last Name";
            // 
            // indivDOBLabel
            // 
            this.indivDOBLabel.AutoSize = true;
            this.indivDOBLabel.Location = new System.Drawing.Point(57, 100);
            this.indivDOBLabel.Name = "indivDOBLabel";
            this.indivDOBLabel.Size = new System.Drawing.Size(38, 17);
            this.indivDOBLabel.TabIndex = 44;
            this.indivDOBLabel.Text = "DOB";
            // 
            // indivLastNameTextBox
            // 
            this.indivLastNameTextBox.Location = new System.Drawing.Point(101, 13);
            this.indivLastNameTextBox.Name = "indivLastNameTextBox";
            this.indivLastNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.indivLastNameTextBox.TabIndex = 41;
            // 
            // indivFirstNameTextBox
            // 
            this.indivFirstNameTextBox.Location = new System.Drawing.Point(101, 41);
            this.indivFirstNameTextBox.Name = "indivFirstNameTextBox";
            this.indivFirstNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.indivFirstNameTextBox.TabIndex = 43;
            // 
            // indivFirstNameLabel
            // 
            this.indivFirstNameLabel.AutoSize = true;
            this.indivFirstNameLabel.Location = new System.Drawing.Point(19, 44);
            this.indivFirstNameLabel.Name = "indivFirstNameLabel";
            this.indivFirstNameLabel.Size = new System.Drawing.Size(76, 17);
            this.indivFirstNameLabel.TabIndex = 42;
            this.indivFirstNameLabel.Text = "First Name";
            // 
            // caregiverTabPage
            // 
            this.caregiverTabPage.Controls.Add(this.careSaveButton);
            this.caregiverTabPage.Controls.Add(this.careApartmentLabel);
            this.caregiverTabPage.Controls.Add(this.careApartmentTextBox);
            this.caregiverTabPage.Controls.Add(this.carePhoneLabel);
            this.caregiverTabPage.Controls.Add(this.carePhoneTextBox);
            this.caregiverTabPage.Controls.Add(this.careRelationshipLabel);
            this.caregiverTabPage.Controls.Add(this.careRelationshipTextBox);
            this.caregiverTabPage.Controls.Add(this.careStateLabel);
            this.caregiverTabPage.Controls.Add(this.careStateTextBox);
            this.caregiverTabPage.Controls.Add(this.careZipLabel);
            this.caregiverTabPage.Controls.Add(this.careZipTextBox);
            this.caregiverTabPage.Controls.Add(this.careCityTextBox);
            this.caregiverTabPage.Controls.Add(this.careCityLabel);
            this.caregiverTabPage.Controls.Add(this.careAddressTextBox);
            this.caregiverTabPage.Controls.Add(this.careAddressLabel);
            this.caregiverTabPage.Controls.Add(this.careSNNTextBox);
            this.caregiverTabPage.Controls.Add(this.careSSNLabel);
            this.caregiverTabPage.Controls.Add(this.careDOBTextBox);
            this.caregiverTabPage.Controls.Add(this.careLastNameLabel);
            this.caregiverTabPage.Controls.Add(this.careDOBLabel);
            this.caregiverTabPage.Controls.Add(this.careLastNameTextBox);
            this.caregiverTabPage.Controls.Add(this.careFirstNameTextBox);
            this.caregiverTabPage.Controls.Add(this.careFirstNameLabel);
            this.caregiverTabPage.Location = new System.Drawing.Point(4, 25);
            this.caregiverTabPage.Name = "caregiverTabPage";
            this.caregiverTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.caregiverTabPage.Size = new System.Drawing.Size(423, 227);
            this.caregiverTabPage.TabIndex = 1;
            this.caregiverTabPage.Text = "Caregiver";
            this.caregiverTabPage.UseVisualStyleBackColor = true;
            // 
            // carePhoneLabel
            // 
            this.carePhoneLabel.AutoSize = true;
            this.carePhoneLabel.Location = new System.Drawing.Point(246, 156);
            this.carePhoneLabel.Name = "carePhoneLabel";
            this.carePhoneLabel.Size = new System.Drawing.Size(49, 17);
            this.carePhoneLabel.TabIndex = 38;
            this.carePhoneLabel.Text = "Phone";
            // 
            // carePhoneTextBox
            // 
            this.carePhoneTextBox.Location = new System.Drawing.Point(301, 153);
            this.carePhoneTextBox.Name = "carePhoneTextBox";
            this.carePhoneTextBox.Size = new System.Drawing.Size(100, 22);
            this.carePhoneTextBox.TabIndex = 37;
            // 
            // careRelationshipLabel
            // 
            this.careRelationshipLabel.AutoSize = true;
            this.careRelationshipLabel.Location = new System.Drawing.Point(9, 72);
            this.careRelationshipLabel.Name = "careRelationshipLabel";
            this.careRelationshipLabel.Size = new System.Drawing.Size(86, 17);
            this.careRelationshipLabel.TabIndex = 36;
            this.careRelationshipLabel.Text = "Relationship";
            // 
            // careRelationshipTextBox
            // 
            this.careRelationshipTextBox.Location = new System.Drawing.Point(101, 69);
            this.careRelationshipTextBox.Name = "careRelationshipTextBox";
            this.careRelationshipTextBox.Size = new System.Drawing.Size(100, 22);
            this.careRelationshipTextBox.TabIndex = 35;
            // 
            // careStateLabel
            // 
            this.careStateLabel.AutoSize = true;
            this.careStateLabel.Location = new System.Drawing.Point(254, 100);
            this.careStateLabel.Name = "careStateLabel";
            this.careStateLabel.Size = new System.Drawing.Size(41, 17);
            this.careStateLabel.TabIndex = 34;
            this.careStateLabel.Text = "State";
            // 
            // careStateTextBox
            // 
            this.careStateTextBox.Location = new System.Drawing.Point(301, 97);
            this.careStateTextBox.Name = "careStateTextBox";
            this.careStateTextBox.Size = new System.Drawing.Size(100, 22);
            this.careStateTextBox.TabIndex = 33;
            // 
            // careZipLabel
            // 
            this.careZipLabel.AutoSize = true;
            this.careZipLabel.Location = new System.Drawing.Point(267, 128);
            this.careZipLabel.Name = "careZipLabel";
            this.careZipLabel.Size = new System.Drawing.Size(28, 17);
            this.careZipLabel.TabIndex = 32;
            this.careZipLabel.Text = "Zip";
            // 
            // careZipTextBox
            // 
            this.careZipTextBox.Location = new System.Drawing.Point(301, 125);
            this.careZipTextBox.Name = "careZipTextBox";
            this.careZipTextBox.Size = new System.Drawing.Size(100, 22);
            this.careZipTextBox.TabIndex = 31;
            // 
            // careCityTextBox
            // 
            this.careCityTextBox.Location = new System.Drawing.Point(301, 69);
            this.careCityTextBox.Name = "careCityTextBox";
            this.careCityTextBox.Size = new System.Drawing.Size(100, 22);
            this.careCityTextBox.TabIndex = 30;
            // 
            // careCityLabel
            // 
            this.careCityLabel.AutoSize = true;
            this.careCityLabel.Location = new System.Drawing.Point(264, 72);
            this.careCityLabel.Name = "careCityLabel";
            this.careCityLabel.Size = new System.Drawing.Size(31, 17);
            this.careCityLabel.TabIndex = 29;
            this.careCityLabel.Text = "City";
            // 
            // careAddressTextBox
            // 
            this.careAddressTextBox.Location = new System.Drawing.Point(301, 13);
            this.careAddressTextBox.Name = "careAddressTextBox";
            this.careAddressTextBox.Size = new System.Drawing.Size(100, 22);
            this.careAddressTextBox.TabIndex = 28;
            // 
            // careAddressLabel
            // 
            this.careAddressLabel.AutoSize = true;
            this.careAddressLabel.Location = new System.Drawing.Point(235, 16);
            this.careAddressLabel.Name = "careAddressLabel";
            this.careAddressLabel.Size = new System.Drawing.Size(60, 17);
            this.careAddressLabel.TabIndex = 20;
            this.careAddressLabel.Text = "Address";
            this.careAddressLabel.Click += new System.EventHandler(this.careAddressLabel_Click);
            // 
            // careSNNTextBox
            // 
            this.careSNNTextBox.Location = new System.Drawing.Point(101, 125);
            this.careSNNTextBox.Name = "careSNNTextBox";
            this.careSNNTextBox.Size = new System.Drawing.Size(100, 22);
            this.careSNNTextBox.TabIndex = 27;
            // 
            // careSSNLabel
            // 
            this.careSSNLabel.AutoSize = true;
            this.careSSNLabel.Location = new System.Drawing.Point(59, 128);
            this.careSSNLabel.Name = "careSSNLabel";
            this.careSSNLabel.Size = new System.Drawing.Size(36, 17);
            this.careSSNLabel.TabIndex = 26;
            this.careSSNLabel.Text = "SSN";
            this.careSSNLabel.Click += new System.EventHandler(this.label7_Click);
            // 
            // careDOBTextBox
            // 
            this.careDOBTextBox.Location = new System.Drawing.Point(101, 97);
            this.careDOBTextBox.Name = "careDOBTextBox";
            this.careDOBTextBox.Size = new System.Drawing.Size(100, 22);
            this.careDOBTextBox.TabIndex = 25;
            // 
            // careLastNameLabel
            // 
            this.careLastNameLabel.AutoSize = true;
            this.careLastNameLabel.Location = new System.Drawing.Point(19, 16);
            this.careLastNameLabel.Name = "careLastNameLabel";
            this.careLastNameLabel.Size = new System.Drawing.Size(76, 17);
            this.careLastNameLabel.TabIndex = 19;
            this.careLastNameLabel.Text = "Last Name";
            // 
            // careDOBLabel
            // 
            this.careDOBLabel.AutoSize = true;
            this.careDOBLabel.Location = new System.Drawing.Point(57, 100);
            this.careDOBLabel.Name = "careDOBLabel";
            this.careDOBLabel.Size = new System.Drawing.Size(38, 17);
            this.careDOBLabel.TabIndex = 24;
            this.careDOBLabel.Text = "DOB";
            // 
            // careLastNameTextBox
            // 
            this.careLastNameTextBox.Location = new System.Drawing.Point(101, 13);
            this.careLastNameTextBox.Name = "careLastNameTextBox";
            this.careLastNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.careLastNameTextBox.TabIndex = 21;
            // 
            // careFirstNameTextBox
            // 
            this.careFirstNameTextBox.Location = new System.Drawing.Point(101, 41);
            this.careFirstNameTextBox.Name = "careFirstNameTextBox";
            this.careFirstNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.careFirstNameTextBox.TabIndex = 23;
            // 
            // careFirstNameLabel
            // 
            this.careFirstNameLabel.AutoSize = true;
            this.careFirstNameLabel.Location = new System.Drawing.Point(19, 44);
            this.careFirstNameLabel.Name = "careFirstNameLabel";
            this.careFirstNameLabel.Size = new System.Drawing.Size(76, 17);
            this.careFirstNameLabel.TabIndex = 22;
            this.careFirstNameLabel.Text = "First Name";
            // 
            // perpetratorTabPage
            // 
            this.perpetratorTabPage.Controls.Add(this.perpSaveButton);
            this.perpetratorTabPage.Controls.Add(this.perpApartmentLabel);
            this.perpetratorTabPage.Controls.Add(this.perpApartmentTextBox);
            this.perpetratorTabPage.Controls.Add(this.perpPhoneLabel);
            this.perpetratorTabPage.Controls.Add(this.perpPhoneTextBox);
            this.perpetratorTabPage.Controls.Add(this.perpRelationshipLabel);
            this.perpetratorTabPage.Controls.Add(this.perpRelationshipTextBox);
            this.perpetratorTabPage.Controls.Add(this.perpStateLabel);
            this.perpetratorTabPage.Controls.Add(this.perpStateTextBox);
            this.perpetratorTabPage.Controls.Add(this.perpZipLabel);
            this.perpetratorTabPage.Controls.Add(this.perpZipTextBox);
            this.perpetratorTabPage.Controls.Add(this.perpCityTextBox);
            this.perpetratorTabPage.Controls.Add(this.perpCityLabel1);
            this.perpetratorTabPage.Controls.Add(this.perpAddressTextBox);
            this.perpetratorTabPage.Controls.Add(this.perpAddressLabel);
            this.perpetratorTabPage.Controls.Add(this.perpSSNTextBox);
            this.perpetratorTabPage.Controls.Add(this.perpSSNLabel);
            this.perpetratorTabPage.Controls.Add(this.perpDOBTextBox);
            this.perpetratorTabPage.Controls.Add(this.perpLastNameLabel);
            this.perpetratorTabPage.Controls.Add(this.perpDOBLabel);
            this.perpetratorTabPage.Controls.Add(this.perpLastNameTextBox);
            this.perpetratorTabPage.Controls.Add(this.perpFirstNameTextBox);
            this.perpetratorTabPage.Controls.Add(this.perpFirstNameLabel);
            this.perpetratorTabPage.Location = new System.Drawing.Point(4, 25);
            this.perpetratorTabPage.Name = "perpetratorTabPage";
            this.perpetratorTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.perpetratorTabPage.Size = new System.Drawing.Size(423, 227);
            this.perpetratorTabPage.TabIndex = 2;
            this.perpetratorTabPage.Text = "Perpetrator";
            this.perpetratorTabPage.UseVisualStyleBackColor = true;
            // 
            // perpPhoneLabel
            // 
            this.perpPhoneLabel.AutoSize = true;
            this.perpPhoneLabel.Location = new System.Drawing.Point(246, 156);
            this.perpPhoneLabel.Name = "perpPhoneLabel";
            this.perpPhoneLabel.Size = new System.Drawing.Size(49, 17);
            this.perpPhoneLabel.TabIndex = 18;
            this.perpPhoneLabel.Text = "Phone";
            // 
            // perpPhoneTextBox
            // 
            this.perpPhoneTextBox.Location = new System.Drawing.Point(301, 153);
            this.perpPhoneTextBox.Name = "perpPhoneTextBox";
            this.perpPhoneTextBox.Size = new System.Drawing.Size(100, 22);
            this.perpPhoneTextBox.TabIndex = 17;
            // 
            // perpRelationshipLabel
            // 
            this.perpRelationshipLabel.AutoSize = true;
            this.perpRelationshipLabel.Location = new System.Drawing.Point(9, 72);
            this.perpRelationshipLabel.Name = "perpRelationshipLabel";
            this.perpRelationshipLabel.Size = new System.Drawing.Size(86, 17);
            this.perpRelationshipLabel.TabIndex = 16;
            this.perpRelationshipLabel.Text = "Relationship";
            // 
            // perpRelationshipTextBox
            // 
            this.perpRelationshipTextBox.Location = new System.Drawing.Point(101, 69);
            this.perpRelationshipTextBox.Name = "perpRelationshipTextBox";
            this.perpRelationshipTextBox.Size = new System.Drawing.Size(100, 22);
            this.perpRelationshipTextBox.TabIndex = 15;
            // 
            // perpStateLabel
            // 
            this.perpStateLabel.AutoSize = true;
            this.perpStateLabel.Location = new System.Drawing.Point(254, 100);
            this.perpStateLabel.Name = "perpStateLabel";
            this.perpStateLabel.Size = new System.Drawing.Size(41, 17);
            this.perpStateLabel.TabIndex = 14;
            this.perpStateLabel.Text = "State";
            // 
            // perpStateTextBox
            // 
            this.perpStateTextBox.Location = new System.Drawing.Point(301, 97);
            this.perpStateTextBox.Name = "perpStateTextBox";
            this.perpStateTextBox.Size = new System.Drawing.Size(100, 22);
            this.perpStateTextBox.TabIndex = 13;
            // 
            // perpZipLabel
            // 
            this.perpZipLabel.AutoSize = true;
            this.perpZipLabel.Location = new System.Drawing.Point(267, 128);
            this.perpZipLabel.Name = "perpZipLabel";
            this.perpZipLabel.Size = new System.Drawing.Size(28, 17);
            this.perpZipLabel.TabIndex = 12;
            this.perpZipLabel.Text = "Zip";
            // 
            // perpZipTextBox
            // 
            this.perpZipTextBox.Location = new System.Drawing.Point(301, 125);
            this.perpZipTextBox.Name = "perpZipTextBox";
            this.perpZipTextBox.Size = new System.Drawing.Size(100, 22);
            this.perpZipTextBox.TabIndex = 11;
            // 
            // perpCityTextBox
            // 
            this.perpCityTextBox.Location = new System.Drawing.Point(301, 69);
            this.perpCityTextBox.Name = "perpCityTextBox";
            this.perpCityTextBox.Size = new System.Drawing.Size(100, 22);
            this.perpCityTextBox.TabIndex = 10;
            // 
            // perpCityLabel1
            // 
            this.perpCityLabel1.AutoSize = true;
            this.perpCityLabel1.Location = new System.Drawing.Point(264, 72);
            this.perpCityLabel1.Name = "perpCityLabel1";
            this.perpCityLabel1.Size = new System.Drawing.Size(31, 17);
            this.perpCityLabel1.TabIndex = 9;
            this.perpCityLabel1.Text = "City";
            // 
            // perpAddressTextBox
            // 
            this.perpAddressTextBox.Location = new System.Drawing.Point(301, 13);
            this.perpAddressTextBox.Name = "perpAddressTextBox";
            this.perpAddressTextBox.Size = new System.Drawing.Size(100, 22);
            this.perpAddressTextBox.TabIndex = 8;
            // 
            // perpAddressLabel
            // 
            this.perpAddressLabel.AutoSize = true;
            this.perpAddressLabel.Location = new System.Drawing.Point(235, 16);
            this.perpAddressLabel.Name = "perpAddressLabel";
            this.perpAddressLabel.Size = new System.Drawing.Size(60, 17);
            this.perpAddressLabel.TabIndex = 0;
            this.perpAddressLabel.Text = "Address";
            // 
            // perpSSNTextBox
            // 
            this.perpSSNTextBox.Location = new System.Drawing.Point(101, 125);
            this.perpSSNTextBox.Name = "perpSSNTextBox";
            this.perpSSNTextBox.Size = new System.Drawing.Size(100, 22);
            this.perpSSNTextBox.TabIndex = 7;
            // 
            // perpSSNLabel
            // 
            this.perpSSNLabel.AutoSize = true;
            this.perpSSNLabel.Location = new System.Drawing.Point(59, 128);
            this.perpSSNLabel.Name = "perpSSNLabel";
            this.perpSSNLabel.Size = new System.Drawing.Size(36, 17);
            this.perpSSNLabel.TabIndex = 6;
            this.perpSSNLabel.Text = "SSN";
            // 
            // perpDOBTextBox
            // 
            this.perpDOBTextBox.Location = new System.Drawing.Point(101, 97);
            this.perpDOBTextBox.Name = "perpDOBTextBox";
            this.perpDOBTextBox.Size = new System.Drawing.Size(100, 22);
            this.perpDOBTextBox.TabIndex = 5;
            // 
            // perpLastNameLabel
            // 
            this.perpLastNameLabel.AutoSize = true;
            this.perpLastNameLabel.Location = new System.Drawing.Point(19, 16);
            this.perpLastNameLabel.Name = "perpLastNameLabel";
            this.perpLastNameLabel.Size = new System.Drawing.Size(76, 17);
            this.perpLastNameLabel.TabIndex = 0;
            this.perpLastNameLabel.Text = "Last Name";
            // 
            // perpDOBLabel
            // 
            this.perpDOBLabel.AutoSize = true;
            this.perpDOBLabel.Location = new System.Drawing.Point(57, 100);
            this.perpDOBLabel.Name = "perpDOBLabel";
            this.perpDOBLabel.Size = new System.Drawing.Size(38, 17);
            this.perpDOBLabel.TabIndex = 4;
            this.perpDOBLabel.Text = "DOB";
            // 
            // perpLastNameTextBox
            // 
            this.perpLastNameTextBox.Location = new System.Drawing.Point(101, 13);
            this.perpLastNameTextBox.Name = "perpLastNameTextBox";
            this.perpLastNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.perpLastNameTextBox.TabIndex = 1;
            // 
            // perpFirstNameTextBox
            // 
            this.perpFirstNameTextBox.Location = new System.Drawing.Point(101, 41);
            this.perpFirstNameTextBox.Name = "perpFirstNameTextBox";
            this.perpFirstNameTextBox.Size = new System.Drawing.Size(100, 22);
            this.perpFirstNameTextBox.TabIndex = 3;
            // 
            // perpFirstNameLabel
            // 
            this.perpFirstNameLabel.AutoSize = true;
            this.perpFirstNameLabel.Location = new System.Drawing.Point(19, 44);
            this.perpFirstNameLabel.Name = "perpFirstNameLabel";
            this.perpFirstNameLabel.Size = new System.Drawing.Size(76, 17);
            this.perpFirstNameLabel.TabIndex = 2;
            this.perpFirstNameLabel.Text = "First Name";
            // 
            // indivApartmentTextBox
            // 
            this.indivApartmentTextBox.Location = new System.Drawing.Point(301, 41);
            this.indivApartmentTextBox.Name = "indivApartmentTextBox";
            this.indivApartmentTextBox.Size = new System.Drawing.Size(100, 22);
            this.indivApartmentTextBox.TabIndex = 59;
            // 
            // indivApartmentLabel
            // 
            this.indivApartmentLabel.AutoSize = true;
            this.indivApartmentLabel.Location = new System.Drawing.Point(214, 44);
            this.indivApartmentLabel.Name = "indivApartmentLabel";
            this.indivApartmentLabel.Size = new System.Drawing.Size(81, 17);
            this.indivApartmentLabel.TabIndex = 60;
            this.indivApartmentLabel.Text = "Apartment#";
            // 
            // indivSchoolTextBox
            // 
            this.indivSchoolTextBox.Location = new System.Drawing.Point(101, 153);
            this.indivSchoolTextBox.Name = "indivSchoolTextBox";
            this.indivSchoolTextBox.Size = new System.Drawing.Size(100, 22);
            this.indivSchoolTextBox.TabIndex = 61;
            // 
            // indivSchoolLabel
            // 
            this.indivSchoolLabel.AutoSize = true;
            this.indivSchoolLabel.Location = new System.Drawing.Point(44, 156);
            this.indivSchoolLabel.Name = "indivSchoolLabel";
            this.indivSchoolLabel.Size = new System.Drawing.Size(51, 17);
            this.indivSchoolLabel.TabIndex = 62;
            this.indivSchoolLabel.Text = "School";
            // 
            // careApartmentLabel
            // 
            this.careApartmentLabel.AutoSize = true;
            this.careApartmentLabel.Location = new System.Drawing.Point(214, 44);
            this.careApartmentLabel.Name = "careApartmentLabel";
            this.careApartmentLabel.Size = new System.Drawing.Size(81, 17);
            this.careApartmentLabel.TabIndex = 62;
            this.careApartmentLabel.Text = "Apartment#";
            // 
            // careApartmentTextBox
            // 
            this.careApartmentTextBox.Location = new System.Drawing.Point(301, 41);
            this.careApartmentTextBox.Name = "careApartmentTextBox";
            this.careApartmentTextBox.Size = new System.Drawing.Size(100, 22);
            this.careApartmentTextBox.TabIndex = 61;
            // 
            // perpApartmentLabel
            // 
            this.perpApartmentLabel.AutoSize = true;
            this.perpApartmentLabel.Location = new System.Drawing.Point(214, 44);
            this.perpApartmentLabel.Name = "perpApartmentLabel";
            this.perpApartmentLabel.Size = new System.Drawing.Size(81, 17);
            this.perpApartmentLabel.TabIndex = 62;
            this.perpApartmentLabel.Text = "Apartment#";
            // 
            // perpApartmentTextBox
            // 
            this.perpApartmentTextBox.Location = new System.Drawing.Point(301, 41);
            this.perpApartmentTextBox.Name = "perpApartmentTextBox";
            this.perpApartmentTextBox.Size = new System.Drawing.Size(100, 22);
            this.perpApartmentTextBox.TabIndex = 61;
            // 
            // indivSaveButton
            // 
            this.indivSaveButton.Location = new System.Drawing.Point(174, 196);
            this.indivSaveButton.Name = "indivSaveButton";
            this.indivSaveButton.Size = new System.Drawing.Size(75, 25);
            this.indivSaveButton.TabIndex = 63;
            this.indivSaveButton.Text = "Save";
            this.indivSaveButton.UseVisualStyleBackColor = true;
            // 
            // careSaveButton
            // 
            this.careSaveButton.Location = new System.Drawing.Point(174, 196);
            this.careSaveButton.Name = "careSaveButton";
            this.careSaveButton.Size = new System.Drawing.Size(75, 25);
            this.careSaveButton.TabIndex = 64;
            this.careSaveButton.Text = "Save";
            this.careSaveButton.UseVisualStyleBackColor = true;
            // 
            // perpSaveButton
            // 
            this.perpSaveButton.Location = new System.Drawing.Point(174, 196);
            this.perpSaveButton.Name = "perpSaveButton";
            this.perpSaveButton.Size = new System.Drawing.Size(75, 25);
            this.perpSaveButton.TabIndex = 64;
            this.perpSaveButton.Text = "Save";
            this.perpSaveButton.UseVisualStyleBackColor = true;
            // 
            // caseViewExitButton
            // 
            this.caseViewExitButton.Location = new System.Drawing.Point(190, 274);
            this.caseViewExitButton.Name = "caseViewExitButton";
            this.caseViewExitButton.Size = new System.Drawing.Size(75, 45);
            this.caseViewExitButton.TabIndex = 1;
            this.caseViewExitButton.Text = "Exit Case View";
            this.caseViewExitButton.UseVisualStyleBackColor = true;
            // 
            // CaseView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(453, 333);
            this.Controls.Add(this.caseViewExitButton);
            this.Controls.Add(this.individualAtRiskTabControl);
            this.Name = "CaseView";
            this.Text = "CaseView";
            this.individualAtRiskTabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.caregiverTabPage.ResumeLayout(false);
            this.caregiverTabPage.PerformLayout();
            this.perpetratorTabPage.ResumeLayout(false);
            this.perpetratorTabPage.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl individualAtRiskTabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage caregiverTabPage;
        private System.Windows.Forms.TabPage perpetratorTabPage;
        private System.Windows.Forms.Label indivPhoneLabel;
        private System.Windows.Forms.TextBox indivPhoneTextBox;
        private System.Windows.Forms.Label indivRelationshipLabel;
        private System.Windows.Forms.TextBox indivRelationshipTextBox;
        private System.Windows.Forms.Label indivStateLabel;
        private System.Windows.Forms.TextBox indivStateTextBox;
        private System.Windows.Forms.Label indivZipLabel;
        private System.Windows.Forms.TextBox indivZipTextBox;
        private System.Windows.Forms.TextBox indivCityTextBox;
        private System.Windows.Forms.Label indivCityLabel;
        private System.Windows.Forms.TextBox indivAddressTextBox;
        private System.Windows.Forms.Label indivAddressLabel;
        private System.Windows.Forms.TextBox indivSSNTextBox;
        private System.Windows.Forms.Label indivSSNLabel;
        private System.Windows.Forms.TextBox indivDOBTextBox;
        private System.Windows.Forms.Label indivLastNameLabel;
        private System.Windows.Forms.Label indivDOBLabel;
        private System.Windows.Forms.TextBox indivLastNameTextBox;
        private System.Windows.Forms.TextBox indivFirstNameTextBox;
        private System.Windows.Forms.Label indivFirstNameLabel;
        private System.Windows.Forms.Label carePhoneLabel;
        private System.Windows.Forms.TextBox carePhoneTextBox;
        private System.Windows.Forms.Label careRelationshipLabel;
        private System.Windows.Forms.TextBox careRelationshipTextBox;
        private System.Windows.Forms.Label careStateLabel;
        private System.Windows.Forms.TextBox careStateTextBox;
        private System.Windows.Forms.Label careZipLabel;
        private System.Windows.Forms.TextBox careZipTextBox;
        private System.Windows.Forms.TextBox careCityTextBox;
        private System.Windows.Forms.Label careCityLabel;
        private System.Windows.Forms.TextBox careAddressTextBox;
        private System.Windows.Forms.Label careAddressLabel;
        private System.Windows.Forms.TextBox careSNNTextBox;
        private System.Windows.Forms.Label careSSNLabel;
        private System.Windows.Forms.TextBox careDOBTextBox;
        private System.Windows.Forms.Label careLastNameLabel;
        private System.Windows.Forms.Label careDOBLabel;
        private System.Windows.Forms.TextBox careLastNameTextBox;
        private System.Windows.Forms.TextBox careFirstNameTextBox;
        private System.Windows.Forms.Label careFirstNameLabel;
        private System.Windows.Forms.Label perpPhoneLabel;
        private System.Windows.Forms.TextBox perpPhoneTextBox;
        private System.Windows.Forms.Label perpRelationshipLabel;
        private System.Windows.Forms.TextBox perpRelationshipTextBox;
        private System.Windows.Forms.Label perpStateLabel;
        private System.Windows.Forms.TextBox perpStateTextBox;
        private System.Windows.Forms.Label perpZipLabel;
        private System.Windows.Forms.TextBox perpZipTextBox;
        private System.Windows.Forms.TextBox perpCityTextBox;
        private System.Windows.Forms.Label perpCityLabel1;
        private System.Windows.Forms.TextBox perpAddressTextBox;
        private System.Windows.Forms.Label perpAddressLabel;
        private System.Windows.Forms.TextBox perpSSNTextBox;
        private System.Windows.Forms.Label perpSSNLabel;
        private System.Windows.Forms.TextBox perpDOBTextBox;
        private System.Windows.Forms.Label perpLastNameLabel;
        private System.Windows.Forms.Label perpDOBLabel;
        private System.Windows.Forms.TextBox perpLastNameTextBox;
        private System.Windows.Forms.TextBox perpFirstNameTextBox;
        private System.Windows.Forms.Label perpFirstNameLabel;
        private System.Windows.Forms.Label indivSchoolLabel;
        private System.Windows.Forms.TextBox indivSchoolTextBox;
        private System.Windows.Forms.Label indivApartmentLabel;
        private System.Windows.Forms.TextBox indivApartmentTextBox;
        private System.Windows.Forms.Label careApartmentLabel;
        private System.Windows.Forms.TextBox careApartmentTextBox;
        private System.Windows.Forms.Button indivSaveButton;
        private System.Windows.Forms.Button careSaveButton;
        private System.Windows.Forms.Button perpSaveButton;
        private System.Windows.Forms.Label perpApartmentLabel;
        private System.Windows.Forms.TextBox perpApartmentTextBox;
        private System.Windows.Forms.Button caseViewExitButton;
    }
}