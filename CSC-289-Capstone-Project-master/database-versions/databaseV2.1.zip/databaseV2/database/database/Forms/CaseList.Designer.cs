﻿namespace database.Forms
{
    partial class CaseList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.activeCaseListBox = new System.Windows.Forms.ListBox();
            this.viewCaseButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // activeCaseListBox
            // 
            this.activeCaseListBox.FormattingEnabled = true;
            this.activeCaseListBox.ItemHeight = 16;
            this.activeCaseListBox.Location = new System.Drawing.Point(12, 12);
            this.activeCaseListBox.Name = "activeCaseListBox";
            this.activeCaseListBox.Size = new System.Drawing.Size(258, 228);
            this.activeCaseListBox.TabIndex = 0;
            // 
            // viewCaseButton
            // 
            this.viewCaseButton.Location = new System.Drawing.Point(63, 265);
            this.viewCaseButton.Name = "viewCaseButton";
            this.viewCaseButton.Size = new System.Drawing.Size(75, 45);
            this.viewCaseButton.TabIndex = 1;
            this.viewCaseButton.Text = "View Case";
            this.viewCaseButton.UseVisualStyleBackColor = true;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(144, 265);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 45);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Close";
            this.exitButton.UseVisualStyleBackColor = true;
            // 
            // CaseList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(282, 327);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.viewCaseButton);
            this.Controls.Add(this.activeCaseListBox);
            this.Name = "CaseList";
            this.Text = "CaseList";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox activeCaseListBox;
        private System.Windows.Forms.Button viewCaseButton;
        private System.Windows.Forms.Button exitButton;
    }
}