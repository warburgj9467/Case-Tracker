﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace ClassEngine
{
    public class SQLCommands
    {
        //public void LogInRetrieval(string userName, string password)
        //{
        //    ClassEngine.LogIn login = new ClassEngine.LogIn();
        //    System.Data.SqlClient.SqlConnection sqlConnection1 = new System.Data.SqlClient.SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Apollo\\Desktop\\CapStone\\database\\database\\Database1.mdf;Integrated Security=True");

        //    using (sqlConnection1)
        //    {
        //        string data = "Select * from LogIn Where UserName = '" + userName + "'";
        //        System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(data, sqlConnection1);
        //        sqlConnection1.Open();
        //        using (SqlDataReader read = cmd.ExecuteReader())
        //        {
        //            while (read.Read())
        //            {
        //                login._username = read["UserName"].ToString();
        //                login._password = read["Password"].ToString();
        //                login._userID = (int)read["UserID"];
        //            }
        //        }
        //    }
        //    //sqlConnection1.Close();
        //}
    }
}
