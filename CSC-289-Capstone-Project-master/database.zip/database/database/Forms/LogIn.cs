﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ClassEngine;

namespace database
{
    public partial class logInForm : Form
    {
        ClassEngine.SQLCommands com = new ClassEngine.SQLCommands();
        ClassEngine.LogIn login = new ClassEngine.LogIn();
        public logInForm()
        {
            InitializeComponent();
        }

        public void LogInRetrieval(string userName, string password)
        {
            ClassEngine.LogIn login = new ClassEngine.LogIn();
            System.Data.SqlClient.SqlConnection sqlConnection1 = new System.Data.SqlClient.SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Apollo\\Desktop\\CapStone\\database\\database\\Database1.mdf;Integrated Security=True");

            using (sqlConnection1)
            {
                string data = "Select * from LogIn Where UserName = '" + userName + "'";
                System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(data, sqlConnection1);
                sqlConnection1.Open();
                using (SqlDataReader read = cmd.ExecuteReader())
                {
                    while (read.Read())
                    {
                        login._username = read["UserName"].ToString();
                        login._password = read["Password"].ToString();
                        login._userID = (int)read["UserID"];
                    }
                }
                if (userName == login._username)
                {
                    if (password == login._password)
                    {
                        MessageBox.Show("Thank you for using Case Tracker.");
                        Forms.userForm user = new Forms.userForm();
                        user.Show();
                    }
                    else
                    {
                        MessageBox.Show("Sorry but the provided information does not match our records.");
                        usernameTextBox.Clear();
                        passwordTextBox.Clear();
                        usernameTextBox.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Sorry but the provided information does not match our records.");
                    usernameTextBox.Clear();
                    passwordTextBox.Clear();
                    usernameTextBox.Focus();
                }
            }
            sqlConnection1.Close();
        }

        private void logInButton_Click(object sender, EventArgs e)
        {
            string userName = usernameTextBox.Text;
            string password = passwordTextBox.Text;
            LogInRetrieval(userName, password);           
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Thank you for choosing Case Tracker.");
            this.Close();
        }
    }
}
